<?php
$con = mysqli_connect("localhost","root","","practice");
if(!$con)
    die("Connection failed");