function formvalidatefunc()                                    
{ 
    var fname = document.forms["RegForm"]["fName"];  
	var lname = document.forms["RegForm"]["lName"];  	
    var email = document.forms["RegForm"]["EMail"];    
	var comm = document.forms["RegForm"]["Comment"]; 
	
	 if (fname.value.length > 50)                                  
    { 
        window.alert("Please enter valid name."); 
        fname.focus(); 
        return false;
    } 
	  
	 if (fname.value == "First Name")                                  
    { 
        window.alert("Please enter your First name."); 
        fname.focus(); 
        return false; 
    } 
    
	if (lname.value.length > 50)                                  
    { 
        window.alert("Please enter valid name."); 
        lname.focus(); 
        return false; 
    }
     
    if (lname.value == "Last Name")                                  
    { 
        window.alert("Please enter your Last name."); 
        lname.focus(); 
        return false; 
    } 
  
    
    if (email.value == "E-mail")                                   
    { 
        window.alert("Please enter a valid e-mail address."); 
        email.focus(); 
        return false; 
    } 
    
	//Other way to validate the email address
    /*
	if (email.value.indexOf("@", 0) < 0)                 
    { 
        window.alert("Please enter a valid e-mail address."); 
        email.focus(); 
        return false; 
    } 
   
    if (email.value.indexOf(".", 0) < 0)                 
    { 
        window.alert("Please enter a valid e-mail address."); 
        email.focus(); 
        return false; 
    } */
	if (!validateEmail(email.value))                                  
    { 
        window.alert("Please enter valid email."); 
        email.focus(); 
        return false; 
    }
   
    return true; 
}


function validateEmail(email) 
{
    var re = /\S+@\S+/;
    return re.test(email);
}
	