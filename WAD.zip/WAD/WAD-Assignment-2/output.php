<!DOCTYPE html>
<html lang="en">
<head>
	<title>Muslim Debugger</title>
	<meta charset="UTF-8">
	<meta name="description" content="The blog of a muslim bebugger">
	<meta name="keywords" content="HTML,CSS,XML,JavaScript">
	<meta name="author" content="Munim Iftikhar">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" type="image/png" href="images/favicon.png"/>
	<link rel="stylesheet" type="text/css" href="css/bootStrap.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<script src="js/main.js"></script> 
</head>
<body >

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
	<div class="container">
		<div class="row">
			<div class="d-flex " id="collapsibleNavbar">
			<ul class="navbar-nav">
			  <li class="nav-item nav-link active">
			  <div class="active">Lahore, Pakistan</div>
			  </li>
			  <li class="nav-item nav-link active"> 
				<div class="active">| call me on </div>
			  </li>
			  <li class="nav-item">
				<div><a class="nav-link active" href="tel:+92123456789">+92 123 - 4567890</a></div>
			  </li>    
			</ul>
			</div>
		</div>
		<div class="ml-auto" id="collapsibleNavbar">
			<ul class="navbar-nav">
			  <li class="nav-item nav-link active">
			  <div class="active">My team</div>
			  </li>
			  <li class="nav-item nav-link active">
				<div class="active">| faq</div>
			  </li>
			  <li class="nav-item">
				<img class="nav-link active" src=""></a>
			  </li>    
			</ul>
			</div>
		</div>
	</div>	
</nav>

<header class="jumbotron pading">
	<div class="container ">
		<div class="row align-top d-flex">
			<div class="col-sm-1" style="margin-right:17px">
			<img src="images/logo.png" >
			</div>
			<div class="col-sm-2" style="margin-top:15px">
			<h2>Muslim Debugger</h2>
			</div>
			
			<div class="ml-auto col-sm text-right" >
				<ul class="">
				  <li class="list-inline-item list-inline active">
				  <div class="dropdown">
					  <span>Home</span>
					  <div class="dropdown-content">
						<p>About me</p>
						<p>About Us</p>
						<p>FaQ</p>
						<p>Meet the team</p>
						<p>Contact page 1</p>
						<p>Contact page 2</p>
						<p>Error page</p>
					  </div>
				</div>
				  </li>
				  <li class="list-inline-item list-inline active">
					<div class="dropdown">
					  <span>Pages</span>
					  <div class="dropdown-content">
						<p>About me</p>
						<p>About Us</p>
						<p>FaQ</p>
						<p>Meet the team</p>
						<p>Contact page 1</p>
						<p>Contact page 2</p>
						<p>Error page</p>
					  </div>
					</div>
				  </li>
				  <li class="list-inline-item list-inline active">
				  <div class="dropdown">
					  <span>Portfolio</span>
					  <div class="dropdown-content">
						<p>About me</p>
						<p>About Us</p>
						<p>FaQ</p>
						<p>Meet the team</p>
						<p>Contact page 1</p>
						<p>Contact page 2</p>
						<p>Error page</p>
					  </div>
				</div>
				  </li> 
					<li class="list-inline-item list-inline active">
				  <div class="dropdown">
					  <span>Blog</span>
					  <div class="dropdown-content">
						<p>About me</p>
						<p>About Us</p>
						<p>FaQ</p>
						<p>Meet the team</p>
						<p>Contact page 1</p>
						<p>Contact page 2</p>
						<p>Error page</p>
					  </div>
				</div>
				  </li>
				  <li class="list-inline-item list-inline active">
				  <div class="dropdown">
					  <span>Shop</span>
					  <div class="dropdown-content">
						<p>About me</p>
						<p>About Us</p>
						<p>FaQ</p>
						<p>Meet the team</p>
						<p>Contact page 1</p>
						<p>Contact page 2</p>
						<p>Error page</p>
					  </div>
				</div>
				  </li>
				</ul>
				</div>
			</div>
		</div>
	</div>
	<div class="container ">
		<div class="row align-middle marin">
			<div class="col-sm-4 align-middle">
			<h1 class=" "></h1>
			</div>
			<div class="col align-middle">
			<h1 class=" ">Hi, Debugger</h1>
			</div>
		</div>
	</div>
</header>

<div style="background-color:black">
<div class="container main">
  <div class="row margin1" ><div class="col-sm color"><center><h2>What can I do</h2><center></div></div>
  <div class="row">
    <div class="col-sm-1">
	<img src="images/seo1.png" >
	</div>
	<div class="col-sm-3">
	<h6 class="color">Graphic Designing<h6>
	<p class="font1 color">I have a good experience in graphic designing. Learn it from different courses. Creativity is key of my life.<p>
  </div>
  <div class="col-sm-1">
	<img src="images/seo2.png" >
	</div>
	<div class="col-sm-3">
	<h6 class="color">Powerful Portfolios<h6>
	<p class="font1 color">You can read all of my documentation work and my research papers. You can always find them very helpful for you. If you don't let me know always.<p>
  </div>
  <div class="col-sm-1">
	<img src="images/seo3.png" >
	</div>
	<div class="col-sm-3">
	<h6 class="color">Python ShortCodes<h6>
	<p class="font1 color">As python is great language I have made it my coding language too. Work on several projects. Also have attended Pycon. <p>
  </div>
   </div>
   <div class="row margin1" ><div class="col-sm color"><center><h2>A Little bit about Me</h2><center></div></div>
   <div class="row">
   <div class="col-sm-3">
	<img class="picture" src="images/fsociety.jpg" >
	</div>
	<div class="col-sm-9">
	<h5 class="color">I am a creative person. I always show my creativity in my work whether it is designing or coding. Coding is not only my profession it is also my hobby. I love to debug codes. </h5>
	<p class="font1 color">I'm a Bachelor's student of Computer science. I've worked on several projects during my styding. Other than core courses I also study some extra courses like WAD,Intro to Pyhon,Graphic designing,Data science with python and last but not the least pycon and many oher courses. <p>
	<p class="font1 color">In the summer of 2015, my family restricted my time on electronic devices and asked me to develop fruitful hobbies. It was during this time that I stumbled upon Computer Science and have never looked back since. That summer, I completed an introductory course in Python through Coursera. Since then, I’ve also completed an additional course in Processing JS through edX. This was followed by the World Web Consortium’s professional certification in front-end web development. Of all the courses I’ve completed, the ones in front end web development that have helped me the most in my personal projects. Using the skills and knowledge obtained from this program, I recently developed a webapp for my school, and am currently working on developing a simple mobile application.</p>
  </div>
  </div>
</div></div>

<div style="background-color:black">
<div class="container main" >
  <div class="row margin1" ><div class="col-sm color"><center><h2>Get Connected</h2><center></div></div>
  <div class="row">
  <div class="col-sm-6">
  <h3 class="color">Add Comment</h3>&nbsp
	<h1 class="color">THANK YOU FOR YOUR COMMENT<H1>
  </div>
  <div class="col-sm-6">
  &nbsp <h4 class="color">Contact Info<h4>
	<p class="font2 color">Hey, You can easily contact me. If you need any advice feel easy peasy lemon squezy to contact me. If you want to know about my projects or want to learn anything from feel free to contact me.<p>

	<p class="font2 color"> <b>Address: </b>Lahore, Punjab, Pakistan</p>  
	<p class="font2 color"> <b>E-mail: </b>munim.iftikhar@ucp.edu.pk</p> 
	<p class="font2 color"> <b>Mobile: </b>+923331234567</p> 
  </div>
 </div>
	
 </div></div>

 <footer class="jumbotron text-center">
	<div class="row">
	 <div class="col-3">
		<h4 class="color">About me<h4>
		<p class="font3">BSCS 5th Semester</p>
	 </div>
	<div class="col-3">
		<h4 class="color">Connect with me<h4>
		<p class="font3">Instagram</p>
		<p class="font3">Facebook</p>
		<p class="font3">Twitter</p>
		<p class="font3">Pinterest</p>
		<p class="font3">Vimeo</p>
	 </div>
	 <div class="col-3">
		<h4 class="color">Additional Links<h4>
		<p class="font3">Projects</p>
		<p class="font3">Pages</p>
		<p class="font3">Shop</p>
		<p class="font3">About</p>
		<p class="font3">Contact</p>
	 </div>
	 <div class="col-3">
		<h4 class="color">Contact Me<h4>
		<p class="font3">UCP, Johar Town, Lahore</p>
		<p class="font3">munim.iftikhar@ucp.edu.pk</p>
		<p class="font3">+923331234567</p>
		<p class="font3">+923331234567</p>
		<p class="font3">+923331234567</p>
	 </div>
	 </div>
</footer>

 
</body>
</html>